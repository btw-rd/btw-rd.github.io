import pymel.core as pm
from random import *
nt = pm.nodetypes

print("received")

###############
## Parameters
scale = 1
density = .1
ratio = .7

#########
## Path
print('Path')

rMaxX = 1
rMaxZ = 6
rMinZ = -6
v = 0
a = 0

rl = [(0,0,-6)]
rc = [(0,0,0)]
rr = [(0,0,6)]

for i in range(int(10*scale)):
    a = a + (random()*6-3)
    while (abs(v + a) > 4): a = a + (random()*6-3)
    v = v + a

    newX = rc[-1][0] + 6
    newZ = rc[-1][2] + v

    rc.append((newX, 0, newZ))

    lx = newX + (random()*2-1)
    #ly = gauss(0,1)
    ly = 0
    lz = newZ - (random()*3) - 4

    rx = newX + (random()*2-1)
    #ry = gauss(0,1)
    ry = 0
    rz = newZ + (random()*3) + 4

    rl.append((lx, ly, lz))
    rr.append((rx, ry, rz))

    if lz < rMinZ: rMinZ = lz
    if rz > rMaxZ: rMaxZ = rz

rMaxX = max(rl[-1][0], rc[-1][0], rr[-1][0])

riverPath = pm.curve(
    name='riverPath',
    d=3,
    p=rc
 )
mountainLeft = pm.curve(
    name='mountainLeft',
    d=3,
    p=rl
 )
mountainRight = pm.curve(
    name='mountainRight',
    d=3,
    p=rr
 )

print('Pond')
rCenterX = rMaxX/2
rCenterZ = (rMaxZ + rMinZ) / 2

rSizeX = rMaxX + 2
rSizeZ = (rMaxZ - rMinZ) + 2

# nt.Transform('Pond1').setAttr('translateX', rCenterX)
# nt.Transform('Pond1').setAttr('translateZ', rCenterZ)

# nt.FluidShape('PondShape1').setAttr('dimensionsW', rSizeX)
# nt.FluidShape('PondShape1').setAttr('dimensionsH', rSizeZ)


##############
## New Shore
print('New Shore')

land = []

def shorePlate(start, end):
    global rr, rc, rl
    if(start == end): return

    xMax = max(rr[end][0], rc[end][0], rl[end][0])
    xMin = max(rr[start][0], rc[start][0], rl[start][0])
    zMax = max(i[-1] for i in rr[start:end])
    zMin = min(i[-1] for i in rl[start:end])

    size = (xMax - xMin, zMax - zMin)
    center = ((xMax + xMin)/2, (zMax + zMin)/2)

    land.append(pm.polyPlane(
        name = 'land',
        w = size[0],
        h = size[1] + 3,
        sw = size[0] * 5,
        sh = size[1] * 5
     )[0])

    land[-1].setAttr('translateX', center[0])
    land[-1].setAttr('translateZ', center[1])
    land[-1].setAttr('translateY', 0.02)
    pm.select(land[-1], r=1)
    pm.hyperShade(a='land_shader')

if scale > 6:
    for i in range(scale//6):
        start = 60*i
        end = 60*(i+1)
        shorePlate(start, end)

start = int(60*(scale//6))
end = int(start + 10*(scale%6))
shorePlate(start, end)
pm.select(cl=1)


################
## New Terrain
print('New Terrain')
riverWire = pm.wire(
    land,
    w=('riverPath', 'mountainLeft', 'mountainRight'
    ))[0]

riverWire.setWireDropOffDistance(0, 0.5)
riverWire.setWireDropOffDistance(1, 3)
riverWire.setWireDropOffDistance(2, 3)

pm.xform(riverPath, t=(0,-0.5,0))
pm.xform(mountainLeft, t=(0,2,0))
pm.xform(mountainRight, t=(0,2,0))

########
##Time
# playBackSlider = maya.mel.eval('$tmpVar=$gPlayBackSlider')
# pm.timeControl(gPlayBackSlider)
endTime = scale*11520
pm.playbackOptions(aet = endTime, max = endTime)


################
## Motion Path
pm.pathAnimation(
    'boat_assembly',
    c='riverPathBaseWire',
    f=1,
    fa='x',
    ua='y',
    wut='vector',
    wu=(0,1,0),
    etu=pm.playbackOptions(q=1, aet=1))

pm.selectKey('motionPath1_uValue')
pm.keyTangent(itt='linear', ott='linear')


#############
## Dressing
print('Dressing')
for m in land:
    center = (m.getAttr('translateX'), m.getAttr('translateZ'))
    for v in m.verts:
        loc = v.getPosition() + (center[0],0,center[1])
        dist = riverPath.distanceToPoint(loc)
        if (7 > dist > 1.4):
            if (random() < density):
                if (random() < ratio):
                    obj = pm.instance(
                        'tree_SOURCE',
                        n='tree_',
                    )
                else:
                    obj = pm.instance(
                        'rock_SOURCE',
                        n='rock_',
                    )

                pm.xform(
                    obj,
                    ws=1,
                    t=loc
                    )
                pm.xform(
                    obj,
                    os=1,
                    ro=(0,random()*360,0)
                    )
    
    
    pm.polySmooth(m, dv = 2)

print('Done!')


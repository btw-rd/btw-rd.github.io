
* Synestaether Readme
(please view this file in a programmers text editor, or with a monospace font.)

This game uses the mouse and keyboard. 

The goal is to get the marbles from the emitter (which has a little spout on the side), 
to the bucket (which has a progress bar above it).

** Instructions
There are two modes: create and select.	To switch between modes press space.
Create mode is for adding blocks to the game. Select mode is for 
moving, rotating and deleting blocks that you have already placed.

At any time you may press the purple button on the bottom left to
restart the level. 

| x |
| y |   <--- click buttons on the side bar to
| z |          choose a block to place
               this will put you in create mode.

The number beneath the image of the block indicates how many
of that type you have left.
Use the E and R keys to rotate a block before you place it.


In create mode you can also:

|   |   |   |   |   |
|---+---+---+---+---|
|   |   |   |   |   |
|---+---+---+---+---|
|   |   |   |   |  <---- click on a square in the
|---+---+---+---+---|     ground grid to place a block
|   |   |   |   |   |


+-----------+
|\           \
| \           \
|  \      <---------------+
|   \           \	  |
|    +-----------+	  |
|    |		 |	  |--------- click on the face of
|    |		 |	  |	       of a block to place a block
 \   |	   <--------------+	       against that side
  \  |		 |
   \ |		 |
    \|-----------|



To enter select mode you can press space or right-click.
Once in select mode you can left-click a block that you have placed to select that block.
Use the 3D pyramids that appear around a block to move that block.


                            ^ (north)
                          +-----+                                    
                        / |  o  |  \                           
               (west)   \ |  .  |  /  (east)                        
                          +-----+                              
			     v (south)

			 . = up 
                         o = down


You can use the E and R keys to rotate a selected block in the same way you can 
use them in create mode.
Press X to delete a selected block.


                                                             
                                                              
                                                              
                                                              
                                                              
 




